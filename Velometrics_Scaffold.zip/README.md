# Velometrics

Qt/C++ project scaffold for telemetry overlay design and rendering.
